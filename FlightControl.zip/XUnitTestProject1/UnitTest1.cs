using FlightControlWeb;
using FlightControlWeb.Controllers;
using FlightControlWeb.Data;
using FlightControlWeb.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Moq;
using NUnit.Framework.Internal;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Xunit;
using Assert = Microsoft.VisualStudio.TestTools.UnitTesting.Assert;
using TestMethod = NUnit.Framework.Internal.TestMethod;

namespace XUnitTestProject1
{
    public class UnitTest1
    {
        //test to check the flights
        private async Task<List<Flight>> ReturnFlights()
        {
            List<Flight> list = await Task.Run(() => new List<Flight>());
            //will not apear in the results!!!! because of the time passed
            Flight f1 = new Flight
            {
                Flight_Id = "01",
                Longitude = 20,
                Latitude = 20,
                Passengers = 102,
                Company_Name = "Ortal the Queen!",
                //this is my birth date :)
                Date_Time = "1998-12-27T23:56:21Z",
                Is_External = true

            };
            //will not apear in the results!!!! because of the time passed
            Flight f2 = new Flight
            {
                Flight_Id = "02",
                Longitude = 20,
                Latitude = 20,
                Passengers = 102,
                Company_Name = "Zvi berger and his family",
                Date_Time = "1923-12-26T23:56:21Z",
                Is_External = true

            };
            list.Add(f1);
            list.Add(f2);
            return list;
        }
        //the test to check all the flights appear
        [Fact]
        public void GetFlight_ShouldReturnFlights()
        {
            //add to the db
            using (var context = new DataBase())
            {
                //add flight plan to the db
                context.fpDictionary.Add("00", new FlightPlan
                {
                    Id = "00",
                    Passengers = 660,
                    Company_Name = "ortal company",
                    Initial_Location = new Initial_Location
                    {
                        Longitude = 20,
                        Latitude = 20,
                        Date_Time = "2020-12-26T23:56:21Z"
                    },
                    Segments = new List<Segment>()
                    {
                        new Segment
                        {
                            Longitude = 20,
                            Latitude = 20,
                            Timespan_Seconds=100
                        }
                    }
                });
                context.SaveChanges();
                //the function from the FlightsController 
                Mock<FlightsController> controller = new Mock<FlightsController>(new FlightManager(new FunctionManager(), context));
                controller.Setup(x => x.flight(It.IsAny<string>()))
                    .Returns(ReturnFlights());

                //ACT
                var listFlights = controller.Object.GetAllFlightsTest("2020-12-26T23:56:21Z").Result;

                //Assert
                if (listFlights != null)
                {
                    //check it is equal
                    Assert.AreEqual(listFlights.Count, 1);
                    //check it is not equal 
                    Assert.AreNotEqual(listFlights.Count, 2);
                    Assert.AreNotEqual(listFlights.Count, 3);
                    Assert.AreEqual(listFlights[0].Flight_Id, "00");
                    //check it is not equal
                    Assert.AreNotEqual(listFlights[0].Flight_Id, "01");
                    Assert.AreNotEqual(listFlights[0].Flight_Id, "02");
                    Assert.AreEqual(listFlights[0].Passengers, 660);
                    //check it is not equal
                    Assert.AreNotEqual(listFlights[0].Passengers, 102);
                    Assert.AreEqual(listFlights[0].Is_External, false);
                    //check it is not equal
                    Assert.AreNotEqual(listFlights[0].Is_External, true);
                    //check it is equal
                    Assert.AreEqual(listFlights[0].Company_Name, "ortal company");
                    //check it is not equal
                    Assert.AreNotEqual(listFlights[0].Company_Name, "Zvi berger and his family");
                    //check it is equal
                    Assert.AreEqual(listFlights[0].Date_Time, "2020-12-26T23:56:21Z");
                }
            }

        }
    }
}