﻿let map = L.map('map').setView([0, 0], 1);
let layerGroup = L.layerGroup().addTo(map);

L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
    attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
}).addTo(map);

// Create airplane icon.
let airplaneIcon = L.Icon.extend({
    options: {
        iconSize: [30, 50],
    }
});

let airplane1 = new airplaneIcon({ iconUrl: 'image/paper-plane.png' }),
    airplane2 = new airplaneIcon({ iconUrl: 'image/paper-plane-blue.png' });

function addNewPlaneToMap(latitude, longitude, layer, layer1) {
    layer.addTo(map);
    layer.on('click', function (ev) {
        unMarkPlan();
        showChosenFlight(layer.layerID);
    });
    map.on('click', function () {
        unMarkPlan();
        removeShownChosenFlight(layer1.layerID);
    });
}

// Change all the airplane's color to blue.
function unMarkPlan() {
    if (blueMark != 0) {
        let blackPlan = icons.get(blueMark);
        let bluePlan = icons.get(blueMark + "%");
        changePlaneColorBack(blackPlan, bluePlan);
        clearMap();
    }
}

// Change plane color to pink.
function changePlaneColor(layer, layer1) {
    layer.remove();
    // The same position, color change.
    layer1.addTo(map);
}

// Change plane color to blue.
function changePlaneColorBack(layer, layer1) {
    if (layer1 != null) {
        layer1.remove();
        layer.addTo(map);
    }
}

//Remove plane from map.
function removePlane(idFlight) {
    layer = icons.get(idFlight);
    layer.remove();
    layer1 = icons.get(idFlight + "%");
    layer1.remove();
}

// Add flight rout to plane.
function addRoute(flightPlan) {
    let latlngs = [
        [flightPlan.initial_Location.latitude, flightPlan.initial_Location.longitude]];
    for (let i = 0, seg; seg = flightPlan.segments[i]; i++) {
        let coordinate = [seg.latitude, seg.longitude];
        latlngs.push(coordinate);
    }
    let seg = flightPlan.segments;
    addHomeMarker(flightPlan.initial_Location.latitude, flightPlan.initial_Location.longitude);
    addDestMarker(flightPlan.segments[seg.length - 1].latitude, flightPlan.segments[seg.length - 1].longitude);
    let polyline = L.polyline(latlngs, { color: 'green', dashArray: '5, 5', dashOffset: '0' }).addTo(map);
    map.fitBounds(polyline.getBounds());
}

// DELETE/api/Flights
function deleteFlightPlan(idFlight) {
    let url = "/api/Flights/" + idFlight;
    $.ajax({
        url: url,
        type: 'DELETE',
        success: function (result) {
            console.log(result);
        }
    });
}

// After clicking the Delete button, implement this.
function deleteRow(idFlight, button) {
    // Remove plane path from map.
    // TODO- change and delete
    if (blueMark == idFlight) {
        clearMap();
    } else {
        clearMapNoLine();
    }
    // Remove flight details.
    let i = button.parentNode.parentNode.rowIndex;
    document.getElementById("InnerFlight").deleteRow(i);
    let idTable = document.getElementById("flightID").innerText;
    if (idFlight == idTable) {
        //removeFlightDetails();
        deleteFlightDetails(idFlight);
    }

    // Remove flight from server.
    deleteFlightPlan(idFlight);

    // Remove plane from map.
    removePlane(idFlight);

    // Remove flight from icons
    icons.delete(idFlight);
    icons.delete(idFlight + "%");
}

// Remove flight rout of plane.
function clearMap() {
    for (i in map._layers) {
        if (map._layers[i]._path != undefined) {
            try {
                map.removeLayer(map._layers[i]);
            }
            catch (e) {
                console.log("problem with " + e + map._layers[i]);
            }
        }
    }
    layerGroup.clearLayers();
}

function clearMapNoLine() {
    for (i in map._layers) {
        if (map._layers[i]._path != undefined && map._layers[i]._parts == undefined) {
            try {
                map.removeLayer(map._layers[i]);
            }
            catch (e) {
                console.log("problem with " + e + map._layers[i]);
            }
        }
    }
 }

//home and end path
function addHomeMarker(lat, lon) {
    let iconDest = L.icon({
        iconUrl: 'image/final.png',
        iconSize: [48, 40],
        popupAnchor: [0, 0]
    })
    let marker = L.marker([lat, lon], { icon: iconDest }).addTo(map);
    marker.addTo(layerGroup);
}

function addDestMarker(lat, lon) {
    let iconHome = L.icon({
        iconUrl: 'image/home.png',
        iconSize: [48, 40],
        popupAnchor: [0, 0]
    })
    let marker = L.marker([lat, lon], { icon: iconHome }).addTo(map);
    marker.addTo(layerGroup);
}