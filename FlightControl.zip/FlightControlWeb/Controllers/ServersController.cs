﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using FlightControlWeb.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace FlightControlWeb.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class serversController : ControllerBase
    {
        // interface of flight manager
        private IFlightManager manager;

        //constractor
        public serversController(FlightManager fm)
        {
            this.manager = fm;
        }

        //HTTP request

        // GET: api/servers
        [HttpGet]
        public List<Server> GetAllServers()
        {
            List < Server > servers = manager.GetAllServer();
            return servers;
        }

        // POST: api/servers
        [HttpPost]
        public void AddServer([FromBody] Server server)
        {
            manager.AddServer(server);
        }

        // DELETE: api/ApiWithActions/5
        [HttpDelete("{id}")]
        public void DeleteServer(string id)
        {
            manager.DeleteServerByID(id);
        }
    }
}
