﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using FlightControlWeb.Data;
using FlightControlWeb.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace FlightControlWeb.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class FlightsController : ControllerBase
    {
        // interface of flight manager
        private IFlightManager manager;

        //constractor
        public FlightsController(FlightManager fm)
        {
            this.manager = fm;
        }


        //HTTP request

        // GET: api/Flights?relative_to=<DATE_TIME>
        [HttpGet]
        public async Task<List<Flight>> GetAllFlights (string relative_to)
        {
            // check if the request contains "sync_all"
            string req = Request.QueryString.Value;
            bool isExternal = req.Contains("sync_all");
            Task < List < Flight >> flights = manager.GetAllFlight(relative_to, isExternal);
            return await flights;
        }

        // DELETE: api/Flights/5
        [HttpDelete("{id}")]
        public void DeleteFlight(string id)
        {
            manager.DeleteFlight(id);
        }

        public virtual Task<List<Flight>> flight(string time)
        {
            return manager.RunExternalFlights(time, new List<Flight>());
        }

        public async Task<List<Flight>> GetAllFlightsTest(string relative_to)
        {
            Task<List<Flight>> flights1 = flight(relative_to);
            Task<List<Flight>> flights = manager.GetAllFlight(relative_to, false);
            return await flights;
        }
    }
}
