﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using FlightControlWeb.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace FlightControlWeb.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class FlightPlanController : ControllerBase
    {
        // interface of flight manager
        private IFlightManager manager;

        //constractor
        public FlightPlanController(FlightManager fm)
        {
            this.manager = fm;
        }

        //HTTP request

        // GET: api/FlightPlan/"id"
        [HttpGet("{id}", Name = "Get")]
        public async Task<FlightPlan> GetFlightPlan(string id)
        {
           Task < FlightPlan > flight = manager.GetFlightPlanById(id);
           return await flight;
        }

        // POST: api/FlightPlan
        [HttpPost]
        public FlightPlan AddFlightPlan([FromBody] FlightPlan flightPlan)
        {
            FlightPlan fp = manager.AddFlightPlan(flightPlan);
            return fp;
        }
    }
}
