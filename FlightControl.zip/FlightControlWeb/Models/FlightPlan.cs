﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Text.Json.Serialization;
using Newtonsoft.Json;

namespace FlightControlWeb.Models
{
    public class FlightPlan
    {
        //json proprety
        [JsonProperty("passengers")]
        public int Passengers { get; set; }

        [JsonProperty("company_name")]
        public string Company_Name { get; set; }

        [JsonProperty("initial_location")]
        public Initial_Location Initial_Location { get; set; }

        [JsonProperty("segments")]
        public List<Segment> Segments { get; set; }

        //other proprety
        public string Id { get; set; }

        public string is_External { get; set; }

        public DateTime relativeDate { get; set; }

        public DateTime lastFlightDate { get; set; }

        public DateTime flightDate { get; set; }
    }
}
