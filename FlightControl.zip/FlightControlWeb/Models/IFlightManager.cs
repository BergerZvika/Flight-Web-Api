﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Threading.Tasks;

namespace FlightControlWeb.Models
{
    interface IFlightManager
    {
        //flight function
        Task<List<Flight>> GetAllFlight(string relative_to, bool isExtrnal);
        void DeleteFlight(string id);

        //flight plan function
        Task<FlightPlan> GetFlightPlanById(string id);
        FlightPlan AddFlightPlan(FlightPlan flightPlan);
        Task<List<Flight>> RunExternalFlights(string relative_to, List<Flight> flights);

        //server function
        List<Server> GetAllServer();
        void AddServer(Server s);
        void DeleteServerByID(string id);
    }
}
